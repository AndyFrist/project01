package com.example.ex_xuxiaopeng001.searchphone.mvp.imp;

import android.content.Context;

/**
 * Created by ex-xuxiaopeng001 on 2018/4/26.
 */

public class BasePresenter {
    Context mContext;

    public void attach(Context context) {
        mContext = context;
    }

    public void onPause() {
    }

    public void onResume() {
    }

    public void onDestroy() {
        mContext = null;
    }

}
