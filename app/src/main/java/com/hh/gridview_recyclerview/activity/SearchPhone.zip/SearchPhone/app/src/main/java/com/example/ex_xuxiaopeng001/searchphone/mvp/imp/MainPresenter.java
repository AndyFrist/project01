package com.example.ex_xuxiaopeng001.searchphone.mvp.imp;

import android.util.Log;

import com.example.ex_xuxiaopeng001.searchphone.modle.Phone;
import com.example.ex_xuxiaopeng001.searchphone.mvp.MvpMainView;
import com.example.ex_xuxiaopeng001.searchphone.util.HttpUtil;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by ex-xuxiaopeng001
 * on 2018/4/26.
 */

public class MainPresenter extends BasePresenter {

    String httpUrl = "http://tcc.taobao.com/cc/json/mobile_tel_segment.htm";
    MvpMainView mvpMainView;
    Phone mPhone;

    public Phone getPhoneInfo() {
        return mPhone;
    }
    public MainPresenter(MvpMainView mainView) {
        mvpMainView = mainView;
    }

    public void searchPhoneInfo(String phone) {
        if (phone.length() != 11) {
            mvpMainView.showToast("请输入正确的手机号");
            return;
        }
        mvpMainView.showLoading();
        //http请求处理的逻辑
        sendHttp(phone);
    }

    private void sendHttp(String phone) {
        Map<String, String> map = new HashMap<>();
        map.put("tel", phone);
        HttpUtil httpUtil = new HttpUtil(new HttpUtil.HttpResponse() {
            @Override
            public void onSuccess(Object object) {
                String json = object.toString();
                Log.i("123", "返回json数据： " + json);
                int index = json.indexOf("{");
                json = json.substring(index, json.length());
                mPhone = parseModelWithGson(json);
                mvpMainView.hidenLoading();
                mvpMainView.updateView();
            }

            @Override
            public void onFail(String error) {
                mvpMainView.showToast(error);
                mvpMainView.hidenLoading();
            }
        });
        httpUtil.sendGettHttp(httpUrl, map);
    }

    /**
     * 使用Gson解析返回的json数据
     *
     * @param json
     * @return
     */
    private Phone parseModelWithGson(String json) {
        Gson gson = new Gson();
        return gson.fromJson(json, Phone.class);
    }

}