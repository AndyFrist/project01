package com.example.ex_xuxiaopeng001.searchphone.util;

import android.os.Handler;
import android.os.Looper;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by ex-xuxiaopeng001
 * on 2018/4/26.
 */

public class HttpUtil {

    private static final String APIKEY = "http://apistore.baidu.com/apiworks/servicedetail/498.html";
    String mUrl;
    Map<String, String> mParm;
    HttpResponse mHttpResponse;
    private final OkHttpClient client = new OkHttpClient();
    //全局handler
    Handler mHandler = new Handler(Looper.getMainLooper());

    //http请求回调
    public interface HttpResponse {
        void onSuccess(Object object);

        void onFail(String error);
    }
    //http回调函数

    public HttpUtil(HttpResponse mHttpResponse) {
        this.mHttpResponse = mHttpResponse;
    }

    public void sendPostHttp(String url, Map<String, String> parm) {
        sendHttp(url, parm, true);
    }

    public void sendGettHttp(String url, Map<String, String> parm) {
        sendHttp(url, parm, false);
    }

    private void sendHttp(String url, Map<String, String> parm, boolean isPost) {
        mUrl = url;
        mParm = parm;
        //HTTP请求逻辑
        run(isPost);
    }

    private void run(boolean isPost) {
        final Request request = createRequest(isPost);
        //创建请求队列
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                if (mHttpResponse != null) {
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            mHttpResponse.onFail("请求错误");
                        }
                    });
                }
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                if (mHttpResponse == null) {
                    return;
                }
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (!response.isSuccessful()) {
                            mHttpResponse.onFail("请求失败：code" + response);
                        } else {
                            try {
                                mHttpResponse.onSuccess(response.body().string());
                            } catch (IOException e) {
                                e.printStackTrace();
                                mHttpResponse.onFail("结果转换失败");
                            }
                        }
                    }
                });
            }
        });
    }

    private Request createRequest(boolean isPost) {
        Request request;
        if (isPost) {
            MultipartBody.Builder requstBodyBuilder = new MultipartBody.Builder();
            requstBodyBuilder.setType(MultipartBody.FORM);
            //遍历map请求参数
            Iterator<Map.Entry<String, String>> iterator = mParm.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, String> map = iterator.next();
                requstBodyBuilder.addFormDataPart(map.getKey(), map.getValue());
            }
            request = new okhttp3.Request.Builder().url(mUrl)
                    .patch(requstBodyBuilder.build()).build();
        } else {
            String sUrl = mUrl + "?" + mapParmtoString(mParm);
            request = new okhttp3.Request.Builder().url(sUrl).build();
        }

        return request;
    }


    private String mapParmtoString(Map<String, String> mParm) {
        StringBuilder builder = new StringBuilder();
        Iterator<Map.Entry<String, String>> iterator = mParm.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            builder.append(entry.getKey() + "=" + entry.getValue() + "&");
        }
        String str = builder.toString().substring(0, builder.length() - 1);
        return str;
    }
}